from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.Login),
    path('register/', views.register),
    path('WebLogin/', views.Login, name='login'),
    path('menu/', views.menu, name='menu'),
    path('layout/', views.layout, name='layout'),
    path('send/', views.send, name='send'),
    path('change/', views.change, name='change')
]
