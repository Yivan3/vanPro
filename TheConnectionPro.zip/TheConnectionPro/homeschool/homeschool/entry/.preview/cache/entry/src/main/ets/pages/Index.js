import router from '@ohos:router';
import promptAction from '@ohos:promptAction';
import http from '@ohos:net.http';
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__Rstate = new ObservedPropertySimplePU('1', this, "Rstate");
        this.__flag = new ObservedPropertySimplePU('0', this, "flag");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.Rstate !== undefined) {
            this.Rstate = params.Rstate;
        }
        if (params.flag !== undefined) {
            this.flag = params.flag;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__Rstate.purgeDependencyOnElmtId(rmElmtId);
        this.__flag.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__password.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__Rstate.aboutToBeDeleted();
        this.__flag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get Rstate() {
        return this.__Rstate.get();
    }
    set Rstate(newValue) {
        this.__Rstate.set(newValue);
    }
    get flag() {
        return this.__flag.get();
    }
    set flag(newValue) {
        this.__flag.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(16:5)");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.padding({
                left: 20,
                right: 20
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("登录");
            Text.debugLine("pages/Index.ets(17:7)");
            Text.fontSize(50);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({
                bottom: 60
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(22:7)");
            Row.width("100%");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("用户名");
            Text.debugLine("pages/Index.ets(23:9)");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(28:7)");
            Row.margin({
                bottom: 8,
                top: 8
            });
            Row.width("100%");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.homeschool", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(29:9)");
            Image.width(30);
            Image.margin({ right: 25 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入用户名"
            });
            TextInput.debugLine("pages/Index.ets(31:9)");
            TextInput.width(200);
            TextInput.onChange((value) => {
                this.username = value;
                console.info(this.username);
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/Index.ets(43:7)");
            Divider.strokeWidth(4);
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(45:7)");
            Row.width("100%");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("密码");
            Text.debugLine("pages/Index.ets(46:9)");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({
                bottom: 8,
                top: 8
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(54:7)");
            Row.width("100%");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.homeschool", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(55:9)");
            Image.width(30);
            Image.margin({ right: 25 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: "请输入密码"
            });
            TextInput.debugLine("pages/Index.ets(57:9)");
            TextInput.width(200);
            TextInput.onChange((value) => {
                this.password = value;
                console.info(this.password);
            });
            TextInput.type(InputType.Password);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/Index.ets(66:7)");
            Divider.strokeWidth(4);
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(67:7)");
            Row.width("100%");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/Index.ets(68:9)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("忘记密码？");
            Text.debugLine("pages/Index.ets(69:9)");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 这是选择框
            Row.create();
            Row.debugLine("pages/Index.ets(75:7)");
            // 这是选择框
            Row.width('100%');
            // 这是选择框
            Row.justifyContent(FlexAlign.SpaceAround);
            if (!isInitialRender) {
                // 这是选择框
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(76:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: 'Radio1', group: 'radioGroup' });
            Radio.debugLine("pages/Index.ets(77:11)");
            Radio.checked(true);
            Radio.height(35);
            Radio.width(35);
            Radio.onChange((isChecked) => {
                if (isChecked) {
                    this.Rstate = '1';
                    promptAction.showToast({ message: '你已选择家长登录' });
                }
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('家长');
            Text.debugLine("pages/Index.ets(87:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(89:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: 'Radio2', group: 'radioGroup' });
            Radio.debugLine("pages/Index.ets(90:11)");
            Radio.height(35);
            Radio.width(35);
            Radio.onChange((isChecked) => {
                if (isChecked) {
                    this.Rstate = '2';
                    promptAction.showToast({ message: '你已选择教师登录' });
                }
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('教师');
            Text.debugLine("pages/Index.ets(99:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        // 这是选择框
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("登陆");
            Button.debugLine("pages/Index.ets(104:7)");
            Button.width("90%");
            Button.height(60);
            Button.backgroundColor(Color.Orange);
            Button.onClick(() => {
                if (this.username != "" && this.password != "") {
                    // 每一个httpRequest对应一个HTTP请求任务，不可复用
                    let httpRequest = http.createHttp();
                    // 用于订阅HTTP响应头，此接口会比request请求先返回。可以根据业务需要订阅此消息
                    // 从API 8开始，使用on('headersReceive', Callback)替代on('headerReceive', AsyncCallback)。 8+
                    httpRequest.on('headersReceive', (header) => {
                        console.info('header: ' + JSON.stringify(header));
                    });
                    httpRequest.request(
                    // 填写HTTP请求的URL地址，可以带参数也可以不带参数。URL地址需要开发者自定义。请求的参数可以在extraData中指定
                    "127.0.0.1:8000/connection/login/", {
                        method: http.RequestMethod.POST,
                        // 开发者根据自身业务需要添加header字段
                        header: {
                            'Content-Type': 'application/json'
                        },
                        // 当使用POST请求时此字段用于传递内容
                        extraData: {
                            "username": this.username,
                            "password": this.password,
                            "identify": this.Rstate
                        },
                        expectDataType: http.HttpDataType.STRING,
                        usingCache: true,
                        priority: 1,
                        connectTimeout: 60000,
                        readTimeout: 60000,
                        usingProtocol: http.HttpProtocol.HTTP1_1, // 可选，协议类型默认值由系统自动指定
                    }, (err, data) => {
                        if (!err) {
                            // data.result为HTTP响应内容，可根据业务需要进行解析
                            console.info('Result:' + JSON.stringify(data.result));
                            console.info('code:' + JSON.stringify(data.responseCode));
                            // data.header为HTTP响应头，可根据业务需要进行解析
                            console.info('header:' + JSON.stringify(data.header));
                            console.info('cookies:' + JSON.stringify(data.cookies)); // 8+
                            console.info('****************');
                            console.info(typeof data);
                            this.flag = JSON.parse(`${data.result}`).answer;
                            console.info(this.flag);
                            // 进行跳转
                            if (this.flag === 'true') {
                                // 学生家长
                                if (this.Rstate === '1') {
                                    router.pushUrl({
                                        url: "pages/S"
                                    });
                                }
                                else if (this.Rstate === '2') {
                                    //   如果是教师登录
                                    router.pushUrl({
                                        url: "pages/T"
                                    });
                                }
                            }
                            else {
                                promptAction.showToast({
                                    message: "密码或用户名错误，请重新输入"
                                });
                            }
                        }
                        else {
                            console.info('error:' + JSON.stringify(err));
                            // 取消订阅HTTP响应头事件
                            httpRequest.off('headersReceive');
                            // 当该请求使用完毕时，调用destroy方法主动销毁
                            httpRequest.destroy();
                        }
                    });
                }
                else if (this.username === '' && this.password === '') {
                    promptAction.showToast({
                        message: "密码或用户名错误，请重新输入"
                    });
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("立即注册");
            Text.debugLine("pages/Index.ets(184:7)");
            Text.fontSize(18);
            Text.margin({
                top: 20,
            });
            Text.onClick(() => {
                router.pushUrl({
                    url: 'pages/Sregister'
                });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    pageTransition() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            PageTransition.create();
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            PageTransitionEnter.create({ duration: 0 });
            PageTransitionEnter.slide(SlideEffect.Right);
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            PageTransitionExit.create({ delay: 0 });
            PageTransitionExit.translate({ x: 100.0, y: 100.0 });
            PageTransitionExit.opacity(0);
            ViewStackProcessor.StopGetAccessRecording();
        });
        PageTransition.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new LoginPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map