import router from '@ohos:router';
import promptAction from '@ohos:promptAction';
import http from '@ohos:net.http';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.scroller = new Scroller();
        this.__Rstate = new ObservedPropertySimplePU('1', this, "Rstate");
        this.__grade = new ObservedPropertySimplePU('', this, "grade");
        this.__classNumber = new ObservedPropertySimplePU(''
        // 学生信息
        , this, "classNumber");
        this.__student_name = new ObservedPropertySimplePU('', this, "student_name");
        this.__student_id = new ObservedPropertySimplePU('', this, "student_id");
        this.__Sphone = new ObservedPropertySimplePU('', this, "Sphone");
        this.__Spassword = new ObservedPropertySimplePU(''
        // 教师信息
        , this, "Spassword");
        this.__teacher_id = new ObservedPropertySimplePU('', this, "teacher_id");
        this.__teacher_name = new ObservedPropertySimplePU('', this, "teacher_name");
        this.__theClass = new ObservedPropertySimplePU('', this, "theClass");
        this.__Tphone = new ObservedPropertySimplePU('', this, "Tphone");
        this.__subject = new ObservedPropertySimplePU('', this, "subject");
        this.__Tpasssword = new ObservedPropertySimplePU('', this, "Tpasssword");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
        if (params.Rstate !== undefined) {
            this.Rstate = params.Rstate;
        }
        if (params.grade !== undefined) {
            this.grade = params.grade;
        }
        if (params.classNumber !== undefined) {
            this.classNumber = params.classNumber;
        }
        if (params.student_name !== undefined) {
            this.student_name = params.student_name;
        }
        if (params.student_id !== undefined) {
            this.student_id = params.student_id;
        }
        if (params.Sphone !== undefined) {
            this.Sphone = params.Sphone;
        }
        if (params.Spassword !== undefined) {
            this.Spassword = params.Spassword;
        }
        if (params.teacher_id !== undefined) {
            this.teacher_id = params.teacher_id;
        }
        if (params.teacher_name !== undefined) {
            this.teacher_name = params.teacher_name;
        }
        if (params.theClass !== undefined) {
            this.theClass = params.theClass;
        }
        if (params.Tphone !== undefined) {
            this.Tphone = params.Tphone;
        }
        if (params.subject !== undefined) {
            this.subject = params.subject;
        }
        if (params.Tpasssword !== undefined) {
            this.Tpasssword = params.Tpasssword;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Rstate.purgeDependencyOnElmtId(rmElmtId);
        this.__grade.purgeDependencyOnElmtId(rmElmtId);
        this.__classNumber.purgeDependencyOnElmtId(rmElmtId);
        this.__student_name.purgeDependencyOnElmtId(rmElmtId);
        this.__student_id.purgeDependencyOnElmtId(rmElmtId);
        this.__Sphone.purgeDependencyOnElmtId(rmElmtId);
        this.__Spassword.purgeDependencyOnElmtId(rmElmtId);
        this.__teacher_id.purgeDependencyOnElmtId(rmElmtId);
        this.__teacher_name.purgeDependencyOnElmtId(rmElmtId);
        this.__theClass.purgeDependencyOnElmtId(rmElmtId);
        this.__Tphone.purgeDependencyOnElmtId(rmElmtId);
        this.__subject.purgeDependencyOnElmtId(rmElmtId);
        this.__Tpasssword.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Rstate.aboutToBeDeleted();
        this.__grade.aboutToBeDeleted();
        this.__classNumber.aboutToBeDeleted();
        this.__student_name.aboutToBeDeleted();
        this.__student_id.aboutToBeDeleted();
        this.__Sphone.aboutToBeDeleted();
        this.__Spassword.aboutToBeDeleted();
        this.__teacher_id.aboutToBeDeleted();
        this.__teacher_name.aboutToBeDeleted();
        this.__theClass.aboutToBeDeleted();
        this.__Tphone.aboutToBeDeleted();
        this.__subject.aboutToBeDeleted();
        this.__Tpasssword.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get Rstate() {
        return this.__Rstate.get();
    }
    set Rstate(newValue) {
        this.__Rstate.set(newValue);
    }
    get grade() {
        return this.__grade.get();
    }
    set grade(newValue) {
        this.__grade.set(newValue);
    }
    get classNumber() {
        return this.__classNumber.get();
    }
    set classNumber(newValue) {
        this.__classNumber.set(newValue);
    }
    get student_name() {
        return this.__student_name.get();
    }
    set student_name(newValue) {
        this.__student_name.set(newValue);
    }
    get student_id() {
        return this.__student_id.get();
    }
    set student_id(newValue) {
        this.__student_id.set(newValue);
    }
    get Sphone() {
        return this.__Sphone.get();
    }
    set Sphone(newValue) {
        this.__Sphone.set(newValue);
    }
    get Spassword() {
        return this.__Spassword.get();
    }
    set Spassword(newValue) {
        this.__Spassword.set(newValue);
    }
    get teacher_id() {
        return this.__teacher_id.get();
    }
    set teacher_id(newValue) {
        this.__teacher_id.set(newValue);
    }
    get teacher_name() {
        return this.__teacher_name.get();
    }
    set teacher_name(newValue) {
        this.__teacher_name.set(newValue);
    }
    get theClass() {
        return this.__theClass.get();
    }
    set theClass(newValue) {
        this.__theClass.set(newValue);
    }
    get Tphone() {
        return this.__Tphone.get();
    }
    set Tphone(newValue) {
        this.__Tphone.set(newValue);
    }
    get subject() {
        return this.__subject.get();
    }
    set subject(newValue) {
        this.__subject.set(newValue);
    }
    get Tpasssword() {
        return this.__Tpasssword.get();
    }
    set Tpasssword(newValue) {
        this.__Tpasssword.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.Rstate === '1') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(27:7)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(28:9)");
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("欢迎使用学生注册");
                        Text.debugLine("pages/Sregister.ets(29:11)");
                        Text.fontSize(30);
                        Text.textAlign(TextAlign.Center);
                        Text.width("100%");
                        Text.fontColor(Color.White);
                        Text.backgroundColor(Color.Pink);
                        Text.height('10%');
                        Text.margin({
                            bottom: "25%"
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(42:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        Row.onAreaChange((value) => {
                            this.student_name = value.toString();
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("学生姓名：");
                        Text.debugLine("pages/Sregister.ets(43:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(47:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(56:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        Row.onAreaChange((value) => {
                            this.student_id = value.toString();
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("学生学号：");
                        Text.debugLine("pages/Sregister.ets(57:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(61:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(70:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        Row.onAreaChange((value) => {
                            this.Sphone = value.toString();
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("移动电话：");
                        Text.debugLine("pages/Sregister.ets(71:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(75:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(84:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        Row.onAreaChange((value) => {
                            this.Spassword = value.toString();
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("账户密码：");
                        Text.debugLine("pages/Sregister.ets(85:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(89:11)");
                        TextInput.type(InputType.Password);
                        TextInput.width("65%");
                        TextInput.height("7%");
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(99:9)");
                        Row.margin({
                            bottom: "20%"
                        });
                        Row.width('85%');
                        Row.justifyContent(FlexAlign.SpaceBetween);
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("学生班级：");
                        Text.debugLine("pages/Sregister.ets(100:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Select.create([{ value: '一年级' }, { value: '二年级' }, { value: '三年级' }, { value: '四年级' }, { value: '五年级' }, { value: '六年级' },
                            { value: '七年级' }, { value: '八年级' }, { value: '九年级' }]);
                        Select.debugLine("pages/Sregister.ets(104:11)");
                        Select.onSelect((index) => {
                            switch (index) {
                                case 0:
                                    this.grade = '一年级';
                                    break;
                                case 1:
                                    this.grade = '二年级';
                                    break;
                                case 2:
                                    this.grade = '三年级';
                                    break;
                                case 3:
                                    this.grade = '四年级';
                                    break;
                                case 4:
                                    this.grade = '五年级';
                                    break;
                                case 5:
                                    this.grade = '六年级';
                                    break;
                                case 6:
                                    this.grade = '七年级';
                                    break;
                                case 7:
                                    this.grade = '八年级';
                                    break;
                                case 8:
                                    this.grade = '九年级';
                                    break;
                            }
                        });
                        Select.selected(2);
                        Select.value('年级');
                        Select.font({ size: 15, weight: 500 });
                        Select.fontColor('#182431');
                        if (!isInitialRender) {
                            Select.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Select.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Select.create([{ value: '一班' }, { value: '二班' }, { value: '三班' }, { value: '四班' }, { value: '五班' }, { value: '六班' },
                            { value: '七班' }, { value: '八班' }, { value: '九班' }, { value: '十班' }]);
                        Select.debugLine("pages/Sregister.ets(141:11)");
                        Select.onSelect((index) => {
                            switch (index) {
                                case 0:
                                    this.classNumber = '一班';
                                    break;
                                case 1:
                                    this.classNumber = '二班';
                                    break;
                                case 2:
                                    this.classNumber = '三班';
                                    break;
                                case 3:
                                    this.classNumber = '四班';
                                    break;
                                case 4:
                                    this.classNumber = '五班';
                                    break;
                                case 5:
                                    this.classNumber = '六班';
                                    break;
                                case 6:
                                    this.classNumber = '七班';
                                    break;
                                case 7:
                                    this.classNumber = '八班';
                                    break;
                                case 8:
                                    this.classNumber = '九班';
                                    break;
                                case 9:
                                    this.classNumber = '十班';
                                    break;
                            }
                        });
                        Select.selected(2);
                        Select.value('班级');
                        Select.font({ size: 15, weight: 500 });
                        Select.fontColor('#182431');
                        if (!isInitialRender) {
                            Select.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Select.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        // 这是选择框
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(188:9)");
                        // 这是选择框
                        Row.width('100%');
                        // 这是选择框
                        Row.justifyContent(FlexAlign.SpaceAround);
                        if (!isInitialRender) {
                            // 这是选择框
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(189:11)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Radio.create({ value: 'Radio1', group: 'radioGroup' });
                        Radio.debugLine("pages/Sregister.ets(190:13)");
                        Radio.checked(true);
                        Radio.height(35);
                        Radio.width(35);
                        Radio.onChange((isChecked) => {
                            if (isChecked) {
                                this.Rstate = '1';
                                promptAction.showToast({ message: '你已选择家长注册' });
                            }
                        });
                        if (!isInitialRender) {
                            Radio.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('家长');
                        Text.debugLine("pages/Sregister.ets(200:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(202:11)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Radio.create({ value: 'Radio2', group: 'radioGroup' });
                        Radio.debugLine("pages/Sregister.ets(203:13)");
                        Radio.height(35);
                        Radio.width(35);
                        Radio.onChange((isChecked) => {
                            if (isChecked) {
                                this.Rstate = '2';
                                promptAction.showToast({ message: '你已选择教师注册' });
                            }
                        });
                        if (!isInitialRender) {
                            Radio.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('教师');
                        Text.debugLine("pages/Sregister.ets(212:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    // 这是选择框
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel("同意用户协议并注册");
                        Button.debugLine("pages/Sregister.ets(216:9)");
                        Button.width("60%");
                        Button.height(60);
                        Button.backgroundColor(Color.Pink);
                        Button.onClick(() => {
                            if (this.student_name != '' && this.student_id != '' && this.Sphone != '' && this.Spassword != '') {
                                // 每一个httpRequest对应一个HTTP请求任务，不可复用
                                let httpRequest = http.createHttp();
                                // 用于订阅HTTP响应头，此接口会比request请求先返回。可以根据业务需要订阅此消息
                                // 从API 8开始，使用on('headersReceive', Callback)替代on('headerReceive', AsyncCallback)。 8+
                                httpRequest.on('headersReceive', (header) => {
                                    console.info('header: ' + JSON.stringify(header));
                                });
                                httpRequest.request(
                                // 填写HTTP请求的URL地址，可以带参数也可以不带参数。URL地址需要开发者自定义。请求的参数可以在extraData中指定
                                "127.0.0.1:8000/connection/register/", {
                                    method: http.RequestMethod.POST,
                                    // 开发者根据自身业务需要添加header字段
                                    header: {
                                        'Content-Type': 'application/json'
                                    },
                                    // 当使用POST请求时此字段用于传递内容
                                    extraData: {
                                        // 如果是1则是家长
                                        "identify": '1',
                                        'name': this.student_name,
                                        'id': this.student_id,
                                        'phone': this.Sphone,
                                        'password': this.Spassword,
                                        'grade': this.grade,
                                        'class': this.classNumber
                                    },
                                    expectDataType: http.HttpDataType.STRING,
                                    usingCache: true,
                                    priority: 1,
                                    connectTimeout: 60000,
                                    readTimeout: 60000,
                                    usingProtocol: http.HttpProtocol.HTTP1_1, // 可选，协议类型默认值由系统自动指定
                                }, (err, data) => {
                                    if (!err) {
                                        // data.result为HTTP响应内容，可根据业务需要进行解析
                                        console.info('Result:' + JSON.stringify(data.result));
                                        console.info('code:' + JSON.stringify(data.responseCode));
                                        // data.header为HTTP响应头，可根据业务需要进行解析
                                        console.info('header:' + JSON.stringify(data.header));
                                        console.info('cookies:' + JSON.stringify(data.cookies)); // 8+
                                    }
                                    else {
                                        console.info('error:' + JSON.stringify(err));
                                        // 取消订阅HTTP响应头事件
                                        httpRequest.off('headersReceive');
                                        // 当该请求使用完毕时，调用destroy方法主动销毁
                                        httpRequest.destroy();
                                    }
                                });
                                promptAction.showToast({
                                    message: '注册成功！',
                                    duration: 2000
                                });
                                router.pushUrl({
                                    url: 'pages/Index'
                                });
                            }
                            else {
                                promptAction.showToast({
                                    message: '未注册成功！',
                                    duration: 2000
                                });
                                router.pushUrl({
                                    url: 'pages/Index'
                                });
                            }
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.Rstate === '2') {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(289:7)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(290:9)");
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("欢迎使用教师注册");
                        Text.debugLine("pages/Sregister.ets(291:11)");
                        Text.fontSize(30);
                        Text.textAlign(TextAlign.Center);
                        Text.width("100%");
                        Text.fontColor(Color.White);
                        Text.backgroundColor("#c0d9");
                        Text.height('10%');
                        Text.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(304:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("教师姓名：");
                        Text.debugLine("pages/Sregister.ets(305:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(309:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        TextInput.onChange((value) => {
                            this.teacher_name = value.toString();
                        });
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(318:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("移动电话：");
                        Text.debugLine("pages/Sregister.ets(319:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(323:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        TextInput.onChange((value) => {
                            this.Tphone = value.toString();
                        });
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(332:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        Row.width('88%');
                        Row.justifyContent(FlexAlign.SpaceBetween);
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("学生班级：");
                        Text.debugLine("pages/Sregister.ets(333:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Select.create([{ value: '一年级' }, { value: '二年级' }, { value: '三年级' }, { value: '四年级' }, { value: '五年级' }, { value: '六年级' },
                            { value: '七年级' }, { value: '八年级' }, { value: '九年级' }]);
                        Select.debugLine("pages/Sregister.ets(337:11)");
                        Select.onSelect((index) => {
                            switch (index) {
                                case 0:
                                    this.grade = '一年级';
                                    break;
                                case 1:
                                    this.grade = '二年级';
                                    break;
                                case 2:
                                    this.grade = '三年级';
                                    break;
                                case 3:
                                    this.grade = '四年级';
                                    break;
                                case 4:
                                    this.grade = '五年级';
                                    break;
                                case 5:
                                    this.grade = '六年级';
                                    break;
                                case 6:
                                    this.grade = '七年级';
                                    break;
                                case 7:
                                    this.grade = '八年级';
                                    break;
                                case 8:
                                    this.grade = '九年级';
                                    break;
                            }
                        });
                        Select.selected(2);
                        Select.value('年级');
                        Select.font({ size: 15, weight: 500 });
                        Select.fontColor('#182431');
                        if (!isInitialRender) {
                            Select.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Select.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Select.create([{ value: '一班' }, { value: '二班' }, { value: '三班' }, { value: '四班' }, { value: '五班' }, { value: '六班' },
                            { value: '七班' }, { value: '八班' }, { value: '九班' }, { value: '十班' }]);
                        Select.debugLine("pages/Sregister.ets(374:11)");
                        Select.onSelect((index) => {
                            switch (index) {
                                case 0:
                                    this.classNumber = '一班';
                                    break;
                                case 1:
                                    this.classNumber = '二班';
                                    break;
                                case 2:
                                    this.classNumber = '三班';
                                    break;
                                case 3:
                                    this.classNumber = '四班';
                                    break;
                                case 4:
                                    this.classNumber = '五班';
                                    break;
                                case 5:
                                    this.classNumber = '六班';
                                    break;
                                case 6:
                                    this.classNumber = '七班';
                                    break;
                                case 7:
                                    this.classNumber = '八班';
                                    break;
                                case 8:
                                    this.classNumber = '九班';
                                    break;
                                case 9:
                                    this.classNumber = '十班';
                                    break;
                            }
                        });
                        Select.selected(2);
                        Select.value('班级');
                        Select.font({ size: 15, weight: 500 });
                        Select.fontColor('#182431');
                        if (!isInitialRender) {
                            Select.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Select.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(420:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("任课课程：");
                        Text.debugLine("pages/Sregister.ets(421:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(425:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        TextInput.onChange((value) => {
                            this.subject = value.toString();
                        });
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(434:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("账户密码：");
                        Text.debugLine("pages/Sregister.ets(435:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(439:11)");
                        TextInput.type(InputType.Password);
                        TextInput.width("65%");
                        TextInput.height("7%");
                        TextInput.onChange((value) => {
                            this.Tpasssword = value.toString();
                        });
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(449:9)");
                        Row.margin({
                            bottom: "10%"
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("教师工号：");
                        Text.debugLine("pages/Sregister.ets(450:11)");
                        Text.margin({
                            left: '10px',
                        });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        TextInput.create();
                        TextInput.debugLine("pages/Sregister.ets(454:11)");
                        TextInput.width("65%");
                        TextInput.height("7%");
                        TextInput.onChange((value) => {
                            this.teacher_id = value.toString();
                        });
                        if (!isInitialRender) {
                            TextInput.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        // 这是选择框
                        Row.create();
                        Row.debugLine("pages/Sregister.ets(464:9)");
                        // 这是选择框
                        Row.width('100%');
                        // 这是选择框
                        Row.justifyContent(FlexAlign.SpaceAround);
                        if (!isInitialRender) {
                            // 这是选择框
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(465:11)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Radio.create({ value: 'Radio1', group: 'radioGroup' });
                        Radio.debugLine("pages/Sregister.ets(466:13)");
                        Radio.height(35);
                        Radio.width(35);
                        Radio.onChange((isChecked) => {
                            if (isChecked) {
                                this.Rstate = '1';
                                promptAction.showToast({ message: '你已选择家长注册' });
                            }
                        });
                        if (!isInitialRender) {
                            Radio.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('家长');
                        Text.debugLine("pages/Sregister.ets(475:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/Sregister.ets(477:11)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Radio.create({ value: 'Radio2', group: 'radioGroup' });
                        Radio.debugLine("pages/Sregister.ets(478:13)");
                        Radio.checked(true);
                        Radio.height(35);
                        Radio.width(35);
                        Radio.onChange((isChecked) => {
                            if (isChecked) {
                                this.Rstate = '2';
                                promptAction.showToast({ message: '你已选择教师注册' });
                            }
                        });
                        if (!isInitialRender) {
                            Radio.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('教师');
                        Text.debugLine("pages/Sregister.ets(488:13)");
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    // 这是选择框
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel("同意用户协议并注册");
                        Button.debugLine("pages/Sregister.ets(493:9)");
                        Button.width("60%");
                        Button.height(60);
                        Button.backgroundColor("#c0d9");
                        Button.margin({
                            bottom: 0
                        });
                        Button.onClick(() => {
                            if (this.teacher_id != '' && this.teacher_name != '' && this.grade != '' && this.Tphone != '' && this.classNumber && this.Tpasssword != '' && this.subject != '') {
                                // 每一个httpRequest对应一个HTTP请求任务，不可复用
                                let httpRequest = http.createHttp();
                                // 用于订阅HTTP响应头，此接口会比request请求先返回。可以根据业务需要订阅此消息
                                // 从API 8开始，使用on('headersReceive', Callback)替代on('headerReceive', AsyncCallback)。 8+
                                httpRequest.on('headersReceive', (header) => {
                                    console.info('header: ' + JSON.stringify(header));
                                });
                                httpRequest.request(
                                // 填写HTTP请求的URL地址，可以带参数也可以不带参数。URL地址需要开发者自定义。请求的参数可以在extraData中指定
                                "127.0.0.1:8000/connection/register/", {
                                    method: http.RequestMethod.POST,
                                    // 开发者根据自身业务需要添加header字段
                                    header: {
                                        'Content-Type': 'application/json'
                                    },
                                    // 当使用POST请求时此字段用于传递内容
                                    extraData: {
                                        'identify': '2',
                                        'id': this.teacher_id,
                                        'name': this.teacher_name,
                                        'phone': this.Tphone,
                                        'subject': this.subject,
                                        'grade': this.grade,
                                        'class': this.classNumber,
                                        'password': this.Tpasssword
                                    },
                                    expectDataType: http.HttpDataType.STRING,
                                    usingCache: true,
                                    priority: 1,
                                    connectTimeout: 60000,
                                    readTimeout: 60000,
                                    usingProtocol: http.HttpProtocol.HTTP1_1, // 可选，协议类型默认值由系统自动指定
                                }, (err, data) => {
                                    if (!err) {
                                        // data.result为HTTP响应内容，可根据业务需要进行解析
                                        console.info('Result:' + JSON.stringify(data.result));
                                        console.info('code:' + JSON.stringify(data.responseCode));
                                        // data.header为HTTP响应头，可根据业务需要进行解析
                                        console.info('header:' + JSON.stringify(data.header));
                                        console.info('cookies:' + JSON.stringify(data.cookies)); // 8+
                                    }
                                    else {
                                        console.info('error:' + JSON.stringify(err));
                                        // 取消订阅HTTP响应头事件
                                        httpRequest.off('headersReceive');
                                        // 当该请求使用完毕时，调用destroy方法主动销毁
                                        httpRequest.destroy();
                                    }
                                });
                                promptAction.showToast({
                                    message: '注册成功！',
                                    duration: 2000
                                });
                                router.pushUrl({
                                    url: 'pages/Index'
                                });
                            }
                            else {
                                promptAction.showToast({
                                    message: '未注册成功！',
                                    duration: 2000
                                });
                                router.pushUrl({
                                    url: 'pages/Index'
                                });
                            }
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Column.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Sregister.js.map